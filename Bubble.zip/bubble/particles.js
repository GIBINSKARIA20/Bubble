/**
 * particles.js - Particle system for micro-bubbles, pop droplets, sparkles, and shockwaves.
 */

class MiniBubble {
  constructor(x, y, vx = 0, vy = 0) {
    this.x = x;
    this.y = y;
    this.radius = 12 + Math.random() * 16;
    this.baseRadius = this.radius;
    this.vx = vx + (Math.random() - 0.5) * 3;
    this.vy = vy - (1.5 + Math.random() * 2.5); // Buoyancy: floats up
    this.wobblePhase = Math.random() * Math.PI * 2;
    this.wobbleSpeed = 0.05 + Math.random() * 0.05;
    this.hue = Math.floor(Math.random() * 360);
    this.alpha = 0.9;
    this.life = 0;
    this.maxLife = 260 + Math.random() * 180; // frames
    this.popped = false;
  }

  update(bounds) {
    this.life++;
    this.wobblePhase += this.wobbleSpeed;

    // Upward buoyancy & air resistance
    this.vy -= 0.035;
    this.vx += Math.sin(this.wobblePhase) * 0.12;
    this.vx *= 0.98;
    this.vy *= 0.98;

    this.x += this.vx;
    this.y += this.vy;

    // Wobble radius
    this.radius = this.baseRadius + Math.sin(this.wobblePhase * 2) * 1.5;

    // Fade near end of life
    if (this.life > this.maxLife - 40) {
      this.alpha = Math.max(0, (this.maxLife - this.life) / 40);
    }

    // Boundary check
    if (this.y + this.radius < -20 || this.alpha <= 0) {
      this.popped = true;
    }
    if (this.x - this.radius < 0) {
      this.x = this.radius;
      this.vx = Math.abs(this.vx) * 0.6;
    } else if (this.x + this.radius > bounds.width) {
      this.x = bounds.width - this.radius;
      this.vx = -Math.abs(this.vx) * 0.6;
    }
  }

  draw(ctx) {
    if (this.popped || this.alpha <= 0) return;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // Bubble body gradient
    const grad = ctx.createRadialGradient(
      this.x - this.radius * 0.3,
      this.y - this.radius * 0.3,
      this.radius * 0.1,
      this.x,
      this.y,
      this.radius
    );
    grad.addColorStop(0, `hsla(${this.hue}, 85%, 85%, 0.1)`);
    grad.addColorStop(0.7, `hsla(${this.hue + 40}, 80%, 75%, 0.25)`);
    grad.addColorStop(0.95, `hsla(${this.hue + 80}, 90%, 85%, 0.6)`);
    grad.addColorStop(1, `hsla(${this.hue + 120}, 95%, 90%, 0.75)`);

    ctx.beginPath();
    ctx.arc(this.x, this.y, Math.max(1, this.radius), 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    // Bubble rim
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = `hsla(${this.hue + 60}, 90%, 80%, ${this.alpha * 0.8})`;
    ctx.stroke();

    // Specular glossy highlight
    ctx.beginPath();
    ctx.ellipse(
      this.x - this.radius * 0.35,
      this.y - this.radius * 0.35,
      this.radius * 0.3,
      this.radius * 0.16,
      -Math.PI / 4,
      0,
      Math.PI * 2
    );
    ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
    ctx.fill();

    ctx.restore();
  }

  contains(px, py) {
    const dx = px - this.x;
    const dy = py - this.y;
    return dx * dx + dy * dy <= (this.radius + 12) * (this.radius + 12);
  }
}

class PopDroplet {
  constructor(x, y, vx, vy, color) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.radius = 2.5 + Math.random() * 4.5;
    this.color = color || `hsla(${Math.random() * 360}, 90%, 75%, 0.8)`;
    this.alpha = 1.0;
    this.decay = 0.015 + Math.random() * 0.02;
    this.gravity = 0.12;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += this.gravity;
    this.vx *= 0.97;
    this.vy *= 0.97;
    this.alpha -= this.decay;
  }

  draw(ctx) {
    if (this.alpha <= 0) return;
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.alpha);
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();

    // White gleam
    ctx.beginPath();
    ctx.arc(this.x - this.radius * 0.3, this.y - this.radius * 0.3, this.radius * 0.4, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.fill();
    ctx.restore();
  }
}

class ShockwaveRing {
  constructor(x, y, maxRadius = 160) {
    this.x = x;
    this.y = y;
    this.radius = 15;
    this.maxRadius = maxRadius;
    this.growthRate = 7.5;
    this.alpha = 0.85;
  }

  update() {
    this.radius += this.growthRate;
    this.alpha *= 0.91;
  }

  draw(ctx) {
    if (this.alpha <= 0.01) return;
    ctx.save();
    ctx.globalAlpha = this.alpha;
    ctx.lineWidth = 3;
    const grad = ctx.createRadialGradient(this.x, this.y, this.radius * 0.8, this.x, this.y, this.radius);
    grad.addColorStop(0, 'rgba(180, 230, 255, 0)');
    grad.addColorStop(0.8, 'rgba(210, 240, 255, 0.7)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0.9)');
    ctx.strokeStyle = grad;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

class Sparkle {
  constructor(x, y) {
    this.x = x + (Math.random() - 0.5) * 40;
    this.y = y + (Math.random() - 0.5) * 40;
    this.size = 4 + Math.random() * 8;
    this.rotation = Math.random() * Math.PI;
    this.rotSpeed = (Math.random() - 0.5) * 0.15;
    this.alpha = 1.0;
    this.decay = 0.03 + Math.random() * 0.03;
  }

  update() {
    this.rotation += this.rotSpeed;
    this.alpha -= this.decay;
  }

  draw(ctx) {
    if (this.alpha <= 0) return;
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.alpha);
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);

    ctx.fillStyle = '#ffffff';
    // 4-pointed star
    ctx.beginPath();
    const s = this.size;
    ctx.moveTo(0, -s);
    ctx.quadraticCurveTo(0, 0, s, 0);
    ctx.quadraticCurveTo(0, 0, 0, s);
    ctx.quadraticCurveTo(0, 0, -s, 0);
    ctx.quadraticCurveTo(0, 0, 0, -s);
    ctx.fill();

    ctx.restore();
  }
}

class ParticleManager {
  constructor() {
    this.miniBubbles = [];
    this.droplets = [];
    this.shockwaves = [];
    this.sparkles = [];
  }

  spawnMiniBubble(x, y, vx = 0, vy = 0) {
    if (this.miniBubbles.length < 50) {
      this.miniBubbles.push(new MiniBubble(x, y, vx, vy));
      if (window.bubbleAudio) {
        window.bubbleAudio.playMiniBubble();
      }
    }
  }

  createPopBurst(x, y, count = 48) {
    // Shockwave
    this.shockwaves.push(new ShockwaveRing(x, y, 220));

    // Water droplets
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.4;
      const speed = 3.5 + Math.random() * 8.5;
      const vx = Math.cos(angle) * speed;
      const vy = Math.sin(angle) * speed;
      const hue = (i * 12 + Math.random() * 40) % 360;
      const color = `hsla(${hue}, 85%, 80%, 0.85)`;
      this.droplets.push(new PopDroplet(x, y, vx, vy, color));
    }

    // Sparkles
    for (let i = 0; i < 20; i++) {
      this.sparkles.push(new Sparkle(x, y));
    }
  }

  createPokeSparkles(x, y, count = 4) {
    for (let i = 0; i < count; i++) {
      this.sparkles.push(new Sparkle(x, y));
    }
  }

  update(bounds) {
    // Mini bubbles
    for (let i = this.miniBubbles.length - 1; i >= 0; i--) {
      const mb = this.miniBubbles[i];
      mb.update(bounds);
      if (mb.popped) {
        this.miniBubbles.splice(i, 1);
      }
    }

    // Droplets
    for (let i = this.droplets.length - 1; i >= 0; i--) {
      const d = this.droplets[i];
      d.update();
      if (d.alpha <= 0) {
        this.droplets.splice(i, 1);
      }
    }

    // Shockwaves
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.update();
      if (sw.alpha <= 0.01) {
        this.shockwaves.splice(i, 1);
      }
    }

    // Sparkles
    for (let i = this.sparkles.length - 1; i >= 0; i--) {
      const sp = this.sparkles[i];
      sp.update();
      if (sp.alpha <= 0) {
        this.sparkles.splice(i, 1);
      }
    }
  }

  draw(ctx) {
    // Shockwaves underneath
    for (const sw of this.shockwaves) sw.draw(ctx);
    // Mini bubbles
    for (const mb of this.miniBubbles) mb.draw(ctx);
    // Droplets
    for (const d of this.droplets) d.draw(ctx);
    // Sparkles on top
    for (const sp of this.sparkles) sp.draw(ctx);
  }

  popMiniBubbleAt(x, y) {
    for (let i = this.miniBubbles.length - 1; i >= 0; i--) {
      const mb = this.miniBubbles[i];
      if (mb.contains(x, y)) {
        mb.popped = true;
        this.shockwaves.push(new ShockwaveRing(mb.x, mb.y, mb.radius * 2));
        for (let j = 0; j < 8; j++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = 1.5 + Math.random() * 3.5;
          this.droplets.push(
            new PopDroplet(
              mb.x,
              mb.y,
              Math.cos(angle) * speed,
              Math.sin(angle) * speed,
              `hsla(${mb.hue}, 90%, 80%, 0.8)`
            )
          );
        }
        if (window.bubbleAudio) {
          window.bubbleAudio.playMiniBubble();
        }
        return true;
      }
    }
    return false;
  }

  clear() {
    this.miniBubbles = [];
    this.droplets = [];
    this.shockwaves = [];
    this.sparkles = [];
  }
}

window.particleManager = new ParticleManager();

