# 🫧 A Bubble That Doesn't Want to Be Popped

An interactive web application featuring an organic, deformable soft-body soap bubble with physics-based elasticity, volume preservation, procedural iridescent graphics, expressive personality, and interactive sound effects.

---

## 🌟 Features & Interactions

### 1. 🖐 Dragging & Soft-Body Inertia
- Click/touch near the center of the bubble and drag it across the screen.
- As the bubble moves, nodes trail with realistic inertia and wobble back into equilibrium.

### 2. 🤏 Stretching & Pulling
- Click/touch near the rim/perimeter of the bubble to grab and pull it outward like elastic dough.
- The bubble stretches into an elongated teardrop shape, with internal negative pressure thinning its waist.
- As tension builds, an elastic pitch sound increases in frequency.
- Releasing the bubble snaps it back with viscoelastic damped harmonic oscillation.

### 3. 🧱 Squashing Against Screen Edges
- Move or fling the bubble against the screen edges (top, bottom, left, right).
- Boundary collision clamps perimeter vertices against the screen walls while preserving internal area (Shoelace formula volume conservation).
- The compressed sides cause perpendicular sides to bulge outward smoothly, with squishy impact sounds.

### 4. 👉 Poking & Wave Ripples
- Quick click/tap on the bubble to poke it.
- A Gaussian bell-curve inward displacement dents the bubble at the poke location.
- Transverse ripple waves propagate clockwise and counter-clockwise around the perimeter.

### 5. 🫧 Repeated Poking & Mini-Bubble Spawning
- Rapid consecutive pokes (< 500ms apart) agitate the bubble.
- Agitation spawns floating **micro-bubbles** that drift upward with natural buoyancy and sine-wave wobble.
- You can tap on any floating mini-bubble to pop it individually!

### 6. 💥 Breaking Limit & Popping Condition
- As you stretch the bubble beyond 2.5x its resting radius, poke it repeatedly in rapid succession, or squash it with high force, its **Stress Meter** fills up.
- The bubble's facial expression shifts from **Chill & Bubbly 😊** to **Nervous 💧** to wide-eyed trembling **PANIC 😱** with sweatdrops.
- Once stress hits 100%, the bubble bursts into dozens of iridescent droplets, star sparkles, and an expanding shockwave with an explosive pop sound!
- A restart dialog appears with stats (total pokes survived) and a button to re-inflate a new bubble.

### 7. 🛡️ Zen Mode & Toggles
- **Can Pop / Zen Mode**: Toggle invincible mode if you want infinite stress-free deformation without bursting.
- **Face On / Clean Bubble**: Toggle cute cartoon expressions or minimalist sleek bubble look.
- **Sound On / Off**: Built-in Web Audio API procedural sound synthesizer (no external audio files required).

---

## 🚀 How to Run

1. Simply open [`index.html`](file:///c:/Users/Gibin%20Skaria%20Philp/OneDrive/Desktop/new/index.html) in any modern web browser (Chrome, Firefox, Edge, Safari).
2. Alternatively, run a local web server:
   ```bash
   # Using Python
   python -m http.server 8080

   # Using Node.js npx
   npx serve .
   ```
   Then open `http://localhost:8080` in your browser.

---

## 🛠️ Technical Architecture

- **`index.html`**: Semantic markup, full-screen viewport, HUD status overlay, control buttons, and pop modal.
- **`style.css`**: Modern glassmorphic dark theme, responsive layout, fluid CSS animations.
- **`bubble.js`**:
  - 48-node circular mass-spring lattice.
  - Radial center springs ($k_{radial}$), perimeter cohesive springs ($k_{perimeter}$), and rest angle restoration ($k_{shape}$).
  - Volume/area conservation via Shoelace polygon formula ($k_{pressure}$).
  - Screen boundary clamping with inelastic restitution.
  - Catmull-Rom / midpoint quadratic spline renderer.
  - Multi-stop iridescent interference gradient and glossy specular highlights.
- **`particles.js`**: Particle system for buoyant mini-bubbles, pop burst water droplets, star sparkles, and refractive shockwaves.
- **`audio.js`**: Procedural sound synthesizer using the Web Audio API for water plops, rubbery stretch whine, squash thuds, micro-bubble chimes, and burst snaps.
- **`main.js`**: Pointer Events API (multi-touch, mouse, stylus), HiDPI canvas rendering, animation loop, and UI bindings.

