/**
 * bubble.js - Soft-body deformable bubble physics and iridescent visual renderer.
 */

class BubbleNode {
  constructor(angle, radius) {
    this.angle = angle; // Base rest angle in radians
    this.restRadius = radius;
    this.x = 0;
    this.y = 0;
    this.vx = 0;
    this.vy = 0;
    this.pinned = false;
    this.pinTargetX = 0;
    this.pinTargetY = 0;
    this.pinWeight = 0;
  }
}

class DeformableBubble {
  constructor(x, y, radius = 130) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.baseRadius = radius;
    this.targetRadius = radius;
    this.currentRadius = radius;

    // Soft-body mesh
    this.nodeCount = 48;
    this.nodes = [];
    for (let i = 0; i < this.nodeCount; i++) {
      const angle = (Math.PI * 2 * i) / this.nodeCount;
      const node = new BubbleNode(angle, radius);
      node.x = x + Math.cos(angle) * radius;
      node.y = y + Math.sin(angle) * radius;
      this.nodes.push(node);
    }

    // Physics parameters
    this.kRadial = 0.045;       // Spring restoring distance to center
    this.kPerimeter = 0.18;     // Surface tension between adjacent nodes
    this.kShape = 0.035;        // Angular circularity restoration
    this.kPressure = 0.000085;  // Volume / area preservation force
    this.damping = 0.94;        // Viscoelastic damping

    // Target rest area (pi * r^2)
    this.targetArea = Math.PI * radius * radius;

    // State & Personality
    this.popped = false;
    this.invincible = false;    // Zen mode toggle
    this.showFace = true;       // Cute expressive face toggle
    this.stress = 0;            // 0 to 100%
    this.agitation = 0;         // Short-term twitchiness
    this.pokeCount = 0;
    this.lastPokeTime = 0;
    this.rapidPokes = 0;

    // Interaction states
    this.isDragging = false;
    this.isStretching = false;
    this.grabbedNodeIndex = -1;
    this.grabOffsetX = 0;
    this.grabOffsetY = 0;

    // Animation & Face states
    this.time = 0;
    this.eyeTargetX = 0;
    this.eyeTargetY = 0;
    this.currentEyeX = 0;
    this.currentEyeY = 0;
    this.blinkTimer = 0;
    this.isBlinking = false;
    this.mouthState = 'happy'; // 'happy', 'surprised', 'nervous', 'scared'
    this.mouthTimer = 0;

    // Wall collision feedback
    this.wallImpactCooldown = 0;

    // Birth animation
    this.birthProgress = 1.0; // 0 to 1
  }

  reset(x, y, radius = 130) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.baseRadius = radius;
    this.targetRadius = radius;
    this.currentRadius = 10; // Start small for inflating birth effect
    this.targetArea = Math.PI * radius * radius;
    this.popped = false;
    this.stress = 0;
    this.agitation = 0;
    this.pokeCount = 0;
    this.rapidPokes = 0;
    this.lastPokeTime = 0;
    this.isDragging = false;
    this.isStretching = false;
    this.grabbedNodeIndex = -1;
    this.birthProgress = 0.05;

    for (let i = 0; i < this.nodeCount; i++) {
      const angle = (Math.PI * 2 * i) / this.nodeCount;
      const node = this.nodes[i];
      node.angle = angle;
      node.restRadius = radius;
      node.x = x + Math.cos(angle) * 10;
      node.y = y + Math.sin(angle) * 10;
      node.vx = (Math.random() - 0.5) * 2;
      node.vy = (Math.random() - 0.5) * 2;
      node.pinned = false;
      node.pinWeight = 0;
    }

    if (window.bubbleAudio) {
      window.bubbleAudio.playInflate();
    }
  }

  /**
   * Calculates the enclosed 2D polygon area using Shoelace formula.
   */
  calculateArea() {
    let area = 0;
    const n = this.nodeCount;
    for (let i = 0; i < n; i++) {
      const j = (i + 1) % n;
      area += this.nodes[i].x * this.nodes[j].y;
      area -= this.nodes[j].x * this.nodes[i].y;
    }
    return Math.abs(area) * 0.5;
  }

  /**
   * Recalculates center of mass from node positions.
   */
  updateCenterOfMass() {
    let sumX = 0;
    let sumY = 0;
    for (let i = 0; i < this.nodeCount; i++) {
      sumX += this.nodes[i].x;
      sumY += this.nodes[i].y;
    }
    const newX = sumX / this.nodeCount;
    const newY = sumY / this.nodeCount;

    // Bubble velocity based on center shift
    this.vx = (newX - this.x) * 0.2;
    this.vy = (newY - this.y) * 0.2;

    this.x = newX;
    this.y = newY;
  }

  /**
   * Main physics integration step.
   */
  update(bounds, mousePos) {
    if (this.popped) return;

    this.time += 0.035;

    // Inflating birth animation
    if (this.birthProgress < 1.0) {
      this.birthProgress += 0.035;
      if (this.birthProgress > 1.0) this.birthProgress = 1.0;
      this.currentRadius = this.baseRadius * Math.sin(this.birthProgress * (Math.PI / 2));
    } else {
      this.currentRadius = this.baseRadius;
    }

    const n = this.nodeCount;
    const curArea = this.calculateArea();
    // Pressure force: if compressed, pushes outward; if expanded, pulls inward
    const areaDiff = (this.targetArea * (this.currentRadius / this.baseRadius) ** 2) - curArea;
    const pressureMag = areaDiff * this.kPressure;

    // Natural idle gentle floating buoyancy wobble
    const idleFloatX = Math.sin(this.time * 0.8) * 0.35;
    const idleFloatY = Math.cos(this.time * 0.6) * 0.35 - 0.08;

    let totalDeformation = 0;
    let maxDistFromCenter = 0;
    let wallContactNodes = 0;

    // 1. Force calculation for each node
    for (let i = 0; i < n; i++) {
      const node = this.nodes[i];
      if (node.pinned) {
        // Softly blend toward pin target
        node.x += (node.pinTargetX - node.x) * (0.45 * node.pinWeight);
        node.y += (node.pinTargetY - node.y) * (0.45 * node.pinWeight);
        node.vx *= 0.5;
        node.vy *= 0.5;
        continue;
      }

      let fx = idleFloatX;
      let fy = idleFloatY;

      // Center vector
      const dx = node.x - this.x;
      const dy = node.y - this.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 1;
      const nx = dx / dist;
      const ny = dy / dist;

      if (dist > maxDistFromCenter) {
        maxDistFromCenter = dist;
      }

      // Rest radius with subtle organic wobble harmonics
      const organicRipple = Math.sin(this.time * 2 + node.angle * 3) * 2.2 +
                            Math.cos(this.time * 1.5 - node.angle * 2) * 1.8;
      const targetR = this.currentRadius + organicRipple;

      // Radial spring force
      const radialDisp = dist - targetR;
      totalDeformation += Math.abs(radialDisp);
      fx -= nx * radialDisp * this.kRadial;
      fy -= ny * radialDisp * this.kRadial;

      // Circular shape restoration
      const targetShapeX = this.x + Math.cos(node.angle) * targetR;
      const targetShapeY = this.y + Math.sin(node.angle) * targetR;
      fx += (targetShapeX - node.x) * this.kShape;
      fy += (targetShapeY - node.y) * this.kShape;

      // Neighbor surface tension springs (adjacent node cohesion)
      const prev = this.nodes[(i - 1 + n) % n];
      const next = this.nodes[(i + 1) % n];
      fx += (prev.x + next.x - 2 * node.x) * this.kPerimeter;
      fy += (prev.y + next.y - 2 * node.y) * this.kPerimeter;

      // Pressure force (outward normal)
      fx += nx * pressureMag;
      fy += ny * pressureMag;

      // Agitation jitter when stressed
      if (this.agitation > 15) {
        const jitter = (this.agitation / 100) * 0.9;
        fx += (Math.random() - 0.5) * jitter;
        fy += (Math.random() - 0.5) * jitter;
      }

      // Apply forces
      node.vx += fx;
      node.vy += fy;
    }

    // 2. Integration & Wall Boundary Collision (Squashing against edges)
    const padding = 6;
    let hitWallVelocity = 0;

    for (let i = 0; i < n; i++) {
      const node = this.nodes[i];
      node.vx *= this.damping;
      node.vy *= this.damping;

      node.x += node.vx;
      node.y += node.vy;

      let hitWall = false;

      // Left wall
      if (node.x < padding) {
        node.x = padding;
        hitWallVelocity = Math.max(hitWallVelocity, Math.abs(node.vx));
        node.vx = -node.vx * 0.3;
        hitWall = true;
      }
      // Right wall
      else if (node.x > bounds.width - padding) {
        node.x = bounds.width - padding;
        hitWallVelocity = Math.max(hitWallVelocity, Math.abs(node.vx));
        node.vx = -node.vx * 0.3;
        hitWall = true;
      }

      // Top wall
      if (node.y < padding) {
        node.y = padding;
        hitWallVelocity = Math.max(hitWallVelocity, Math.abs(node.vy));
        node.vy = -node.vy * 0.3;
        hitWall = true;
      }
      // Bottom wall
      else if (node.y > bounds.height - padding) {
        node.y = bounds.height - padding;
        hitWallVelocity = Math.max(hitWallVelocity, Math.abs(node.vy));
        node.vy = -node.vy * 0.3;
        hitWall = true;
      }

      if (hitWall) {
        wallContactNodes++;
      }
    }

    this.updateCenterOfMass();

    // Wall squash audio & stress
    if (this.wallImpactCooldown > 0) {
      this.wallImpactCooldown--;
    } else if (wallContactNodes > 3 && hitWallVelocity > 2.0) {
      if (window.bubbleAudio) {
        window.bubbleAudio.playSquash(hitWallVelocity);
      }
      this.agitation = Math.min(100, this.agitation + hitWallVelocity * 4);
      this.wallImpactCooldown = 15;
    }

    // 3. Tension, Stress & Agitation Dynamics
    const stretchRatio = maxDistFromCenter / this.baseRadius;
    const avgDeformation = totalDeformation / n;

    // Tension increases when stretched or flattened severely
    let instantTension = 0;
    if (stretchRatio > 1.3) {
      instantTension = (stretchRatio - 1.3) * 65;
    }
    if (wallContactNodes > 8) {
      instantTension += (wallContactNodes - 8) * 3;
    }

    // Agitation naturally decays
    this.agitation = Math.max(0, this.agitation * 0.965 - 0.08);

    // Stress combines stretch tension, deformation, and agitation
    const targetStress = Math.min(100, instantTension + this.agitation + (avgDeformation > 25 ? avgDeformation * 0.8 : 0));
    // Smooth transition
    this.stress += (targetStress - this.stress) * 0.12;

    // Pop check!
    if (!this.invincible) {
      // Pop condition:
      // 1. Extreme stretch (stretched > 2.5x rest radius)
      // 2. Stress reaches 100%
      // 3. Rapid poking overload
      if (stretchRatio >= 2.55 || this.stress >= 99.5 || this.rapidPokes >= 14) {
        this.pop();
        return;
      }
    }

    // 4. Face & Eye tracking logic
    if (mousePos) {
      const fdx = mousePos.x - this.x;
      const fdy = mousePos.y - this.y;
      const fDist = Math.sqrt(fdx * fdx + fdy * fdy) || 1;
      const eyeMaxOffset = 18;
      const norm = Math.min(1, fDist / 120);
      this.eyeTargetX = (fdx / fDist) * eyeMaxOffset * norm;
      this.eyeTargetY = (fdy / fDist) * eyeMaxOffset * norm;
    }
    this.currentEyeX += (this.eyeTargetX - this.currentEyeX) * 0.15;
    this.currentEyeY += (this.eyeTargetY - this.currentEyeY) * 0.15;

    // Blinking
    this.blinkTimer++;
    if (this.blinkTimer > 180 + Math.random() * 80) {
      this.isBlinking = true;
      if (this.blinkTimer > 192) {
        this.isBlinking = false;
        this.blinkTimer = 0;
      }
    }

    // Mouth expressions
    if (this.mouthTimer > 0) {
      this.mouthTimer--;
    } else {
      if (this.stress > 65) {
        this.mouthState = 'scared';
      } else if (this.stress > 30 || stretchRatio > 1.4) {
        this.mouthState = 'nervous';
      } else {
        this.mouthState = 'happy';
      }
    }
  }

  /**
   * Poking interaction: user clicked or tapped inside/near bubble.
   */
  poke(px, py) {
    if (this.popped) return;

    const dx = px - this.x;
    const dy = py - this.y;
    const distToCenter = Math.sqrt(dx * dx + dy * dy);

    // Detect closest node
    let closestIdx = 0;
    let minDist = Infinity;
    for (let i = 0; i < this.nodeCount; i++) {
      const d = Math.hypot(this.nodes[i].x - px, this.nodes[i].y - py);
      if (d < minDist) {
        minDist = d;
        closestIdx = i;
      }
    }

    const now = performance.now();
    const timeDelta = now - this.lastPokeTime;
    this.lastPokeTime = now;

    if (timeDelta < 500) {
      this.rapidPokes++;
    } else {
      this.rapidPokes = Math.max(0, this.rapidPokes - 1);
    }

    this.pokeCount++;
    this.agitation = Math.min(100, this.agitation + 18 + this.rapidPokes * 6);
    this.mouthState = 'surprised';
    this.mouthTimer = 35;

    // Inward dent impulse on nearest nodes with Gaussian bell curve falloff
    const dentForce = 18 + Math.min(this.rapidPokes * 4, 25);
    const inAngle = Math.atan2(this.y - py, this.x - px);
    const pushInX = Math.cos(inAngle) * dentForce;
    const pushInY = Math.sin(inAngle) * dentForce;

    for (let k = -6; k <= 6; k++) {
      const idx = (closestIdx + k + this.nodeCount) % this.nodeCount;
      const weight = Math.exp(-(k * k) / 8);
      this.nodes[idx].vx += pushInX * weight;
      this.nodes[idx].vy += pushInY * weight;
    }

    // Launch transverse ripple waves
    const rippleSpeed = 8;
    this.nodes[(closestIdx + 3) % this.nodeCount].vx += Math.sin(inAngle + Math.PI / 2) * rippleSpeed;
    this.nodes[(closestIdx - 3 + this.nodeCount) % this.nodeCount].vx -= Math.sin(inAngle + Math.PI / 2) * rippleSpeed;

    // Audio feedback
    if (window.bubbleAudio) {
      window.bubbleAudio.playPoke(Math.min(2.5, 0.8 + this.rapidPokes * 0.3));
    }

    // Particle feedback: If poked repeatedly (>= 3 rapid pokes), spawn micro baby bubbles!
    if (window.particleManager) {
      window.particleManager.createPokeSparkles(px, py, 3);
      if (this.rapidPokes >= 2) {
        const miniVx = (Math.random() - 0.5) * 4 - pushInX * 0.15;
        const miniVy = - (2 + Math.random() * 3);
        window.particleManager.spawnMiniBubble(px, py, miniVx, miniVy);
      }
    }
  }

  /**
   * Start grabbing: determines whether it's center drag or edge stretch.
   */
  startGrab(px, py) {
    if (this.popped) return false;

    const dx = px - this.x;
    const dy = py - this.y;
    const distToCenter = Math.hypot(dx, dy);

    // If outside the outer bounds of the bubble with a threshold, ignore
    if (distToCenter > this.baseRadius * 1.55) {
      return false;
    }

    // Find closest node
    let closestIdx = -1;
    let minDist = Infinity;
    for (let i = 0; i < this.nodeCount; i++) {
      const d = Math.hypot(this.nodes[i].x - px, this.nodes[i].y - py);
      if (d < minDist) {
        minDist = d;
        closestIdx = i;
      }
    }

    if (distToCenter < this.currentRadius * 0.65) {
      this.isDragging = true;
      this.isStretching = false;
      this.grabOffsetX = px - this.x;
      this.grabOffsetY = py - this.y;
    } else {
      this.isStretching = true;
      this.isDragging = false;
      this.grabbedNodeIndex = closestIdx;
      // Note: do not pin nodes yet until pointer actually moves,
      // so quick taps remain pure, instantaneous pokes!
    }
    return true;
  }

  /**
   * Pins node and neighboring nodes with smooth falloff to follow user pointer.
   */
  pinNodesAround(centerIdx, targetX, targetY) {
    const range = 6;
    for (let k = -range; k <= range; k++) {
      const idx = (centerIdx + k + this.nodeCount) % this.nodeCount;
      const weight = Math.cos((k / range) * (Math.PI / 2));
      const node = this.nodes[idx];
      node.pinned = true;
      node.pinWeight = weight;
      node.pinTargetX = targetX;
      node.pinTargetY = targetY;
    }
  }

  /**
   * Drag / Stretch update during pointer move.
   */
  updateGrab(px, py) {
    if (this.popped) return;

    if (this.isDragging) {
      const targetCenterX = px - this.grabOffsetX;
      const targetCenterY = py - this.grabOffsetY;
      const shiftX = (targetCenterX - this.x) * 0.38;
      const shiftY = (targetCenterY - this.y) * 0.38;

      // Move all nodes together while maintaining soft-body inertia
      for (let i = 0; i < this.nodeCount; i++) {
        this.nodes[i].x += shiftX;
        this.nodes[i].y += shiftY;
        this.nodes[i].vx += shiftX * 0.18;
        this.nodes[i].vy += shiftY * 0.18;
      }
      this.updateCenterOfMass();
    } else if (this.isStretching && this.grabbedNodeIndex !== -1) {
      this.pinNodesAround(this.grabbedNodeIndex, px, py);

      // Play soft stretch tension audio
      const dist = Math.hypot(px - this.x, py - this.y);
      const stretchRatio = dist / this.baseRadius;
      if (stretchRatio > 1.25 && window.bubbleAudio) {
        window.bubbleAudio.playStretch(Math.min(1, (stretchRatio - 1.25) / 1.2));
      }
    }
  }

  /**
   * Release grab: unpins all nodes, allowing bubble to spring back smoothly.
   */
  releaseGrab() {
    this.isDragging = false;
    this.isStretching = false;
    this.grabbedNodeIndex = -1;

    for (let i = 0; i < this.nodeCount; i++) {
      this.nodes[i].pinned = false;
      this.nodes[i].pinWeight = 0;
    }
  }

  /**
   * Check if a coordinate is inside the bubble polygon.
   */
  containsPoint(px, py) {
    if (this.popped) return false;
    let inside = false;
    const n = this.nodeCount;
    for (let i = 0, j = n - 1; i < n; j = i++) {
      const xi = this.nodes[i].x, yi = this.nodes[i].y;
      const xj = this.nodes[j].x, yj = this.nodes[j].y;
      const intersect = ((yi > py) !== (yj > py)) &&
                        (px < (xj - xi) * (py - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  /**
   * Pop the bubble!
   */
  pop() {
    if (this.popped) return;
    this.popped = true;
    this.isDragging = false;
    this.isStretching = false;

    // Burst audio
    if (window.bubbleAudio) {
      window.bubbleAudio.playPop();
    }

    // Particle explosion
    if (window.particleManager) {
      window.particleManager.createPopBurst(this.x, this.y, 60);
    }

    // Trigger custom event for UI HUD
    window.dispatchEvent(new CustomEvent('bubblePopped', {
      detail: { pokeCount: this.pokeCount }
    }));
  }

  /**
   * Smooth bezier / cardinal spline perimeter path.
   */
  createPerimeterPath(ctx) {
    const n = this.nodeCount;
    ctx.beginPath();
    // Midpoint quadratic spline for silk-smooth deformation curves
    const firstMidX = (this.nodes[0].x + this.nodes[1].x) * 0.5;
    const firstMidY = (this.nodes[0].y + this.nodes[1].y) * 0.5;
    ctx.moveTo(firstMidX, firstMidY);

    for (let i = 1; i < n; i++) {
      const next = (i + 1) % n;
      const midX = (this.nodes[i].x + this.nodes[next].x) * 0.5;
      const midY = (this.nodes[i].y + this.nodes[next].y) * 0.5;
      ctx.quadraticCurveTo(this.nodes[i].x, this.nodes[i].y, midX, midY);
    }
    ctx.quadraticCurveTo(this.nodes[0].x, this.nodes[0].y, firstMidX, firstMidY);
    ctx.closePath();
  }

  /**
   * Render the deformable bubble with iridescent soap film and expressions.
   */
  draw(ctx) {
    if (this.popped) return;

    ctx.save();

    // 1. Iridescent Body Fill
    this.createPerimeterPath(ctx);

    // Shifting soap film interference gradient
    const hueOffset = (this.time * 25) % 360;
    const bodyGrad = ctx.createRadialGradient(
      this.x - this.currentRadius * 0.35,
      this.y - this.currentRadius * 0.35,
      this.currentRadius * 0.1,
      this.x,
      this.y,
      this.currentRadius * 1.35
    );

    // Stress color shift: turns slightly blush pink/warm violet when agitated
    const stressWarmth = (this.stress / 100) * 45;

    bodyGrad.addColorStop(0, `hsla(${200 + stressWarmth}, 90%, 96%, 0.18)`);
    bodyGrad.addColorStop(0.45, `hsla(${(hueOffset) % 360}, 85%, 85%, 0.22)`);
    bodyGrad.addColorStop(0.75, `hsla(${(hueOffset + 120) % 360}, 90%, 80%, 0.32)`);
    bodyGrad.addColorStop(0.92, `hsla(${(hueOffset + 220) % 360}, 95%, 85%, 0.58)`);
    bodyGrad.addColorStop(1, `hsla(${(hueOffset + 280) % 360}, 100%, 92%, 0.75)`);

    ctx.fillStyle = bodyGrad;
    ctx.fill();

    // 2. Translucent Soap Film Inner Glow & Rim
    ctx.lineWidth = 2.5;
    const rimGrad = ctx.createLinearGradient(
      this.x - this.currentRadius,
      this.y - this.currentRadius,
      this.x + this.currentRadius,
      this.y + this.currentRadius
    );
    rimGrad.addColorStop(0, `hsla(${(hueOffset) % 360}, 100%, 85%, 0.85)`);
    rimGrad.addColorStop(0.5, `hsla(${(hueOffset + 120) % 360}, 95%, 88%, 0.85)`);
    rimGrad.addColorStop(1, `hsla(${(hueOffset + 240) % 360}, 100%, 90%, 0.9)`);
    ctx.strokeStyle = rimGrad;
    ctx.stroke();

    // Clip internal decorations (face, inner reflections) inside the deformed bubble
    ctx.save();
    this.createPerimeterPath(ctx);
    ctx.clip();

    // Subtle internal soap swirls
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.ellipse(
      this.x + Math.sin(this.time) * 15,
      this.y + Math.cos(this.time * 0.8) * 15,
      this.currentRadius * 0.8,
      this.currentRadius * 0.45,
      this.time * 0.2,
      0,
      Math.PI * 2
    );
    const swirlGrad = ctx.createLinearGradient(
      this.x - this.currentRadius,
      this.y,
      this.x + this.currentRadius,
      this.y
    );
    swirlGrad.addColorStop(0, 'rgba(0, 230, 255, 0.4)');
    swirlGrad.addColorStop(0.5, 'rgba(255, 130, 220, 0.4)');
    swirlGrad.addColorStop(1, 'rgba(255, 240, 150, 0.4)');
    ctx.fillStyle = swirlGrad;
    ctx.fill();
    ctx.globalAlpha = 1.0;

    // 3. Cute Expressive Face (if enabled)
    if (this.showFace && this.birthProgress >= 0.85) {
      this.drawFace(ctx);
    }

    ctx.restore(); // Unclip

    // 4. Glossy Specular Highlights (On top of rim)
    this.drawHighlights(ctx);

    ctx.restore();
  }

  /**
   * Glossy crescent reflection highlights.
   */
  drawHighlights(ctx) {
    ctx.save();
    // Primary crescent highlight (top left)
    const hlX = this.x - this.currentRadius * 0.45;
    const hlY = this.y - this.currentRadius * 0.45;
    const hlRadius = this.currentRadius * 0.35;

    ctx.beginPath();
    ctx.ellipse(hlX, hlY, hlRadius, hlRadius * 0.48, -Math.PI / 4, 0, Math.PI * 2);
    const hlGrad = ctx.createLinearGradient(hlX - hlRadius, hlY - hlRadius, hlX + hlRadius, hlY + hlRadius);
    hlGrad.addColorStop(0, 'rgba(255, 255, 255, 0.92)');
    hlGrad.addColorStop(0.7, 'rgba(255, 255, 255, 0.4)');
    hlGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = hlGrad;
    ctx.fill();

    // Small dot highlight next to it
    ctx.beginPath();
    ctx.arc(hlX + hlRadius * 0.5, hlY - hlRadius * 0.3, hlRadius * 0.18, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.fill();

    // Secondary subtle rim bounce (bottom right)
    const brX = this.x + this.currentRadius * 0.48;
    const brY = this.y + this.currentRadius * 0.48;
    ctx.beginPath();
    ctx.ellipse(brX, brY, this.currentRadius * 0.22, this.currentRadius * 0.08, -Math.PI / 4, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.fill();

    ctx.restore();
  }

  /**
   * Expressive cartoon eyes, mouth, sweat drops, and blush.
   */
  drawFace(ctx) {
    ctx.save();

    const eyeSpacing = 32;
    const eyeOffsetY = -10;
    const leftEyeCenterX = this.x - eyeSpacing;
    const rightEyeCenterX = this.x + eyeSpacing;
    const eyeY = this.y + eyeOffsetY;

    // Blushing cheeks
    const blushAlpha = Math.min(0.65, 0.25 + (this.stress / 100) * 0.4);
    ctx.fillStyle = `rgba(255, 105, 140, ${blushAlpha})`;
    ctx.beginPath();
    ctx.ellipse(leftEyeCenterX - 14, eyeY + 22, 12, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(rightEyeCenterX + 14, eyeY + 22, 12, 7, 0, 0, Math.PI * 2);
    ctx.fill();

    // Sweatdrop when panic/stressed > 60%
    if (this.stress > 60) {
      const dropX = rightEyeCenterX + 26;
      const dropY = eyeY - 24 + Math.sin(this.time * 6) * 3;
      ctx.fillStyle = 'rgba(120, 220, 255, 0.88)';
      ctx.beginPath();
      ctx.moveTo(dropX, dropY - 12);
      ctx.quadraticCurveTo(dropX + 9, dropY - 2, dropX + 8, dropY + 6);
      ctx.arc(dropX, dropY + 6, 8, 0, Math.PI);
      ctx.quadraticCurveTo(dropX - 9, dropY - 2, dropX, dropY - 12);
      ctx.fill();
      // Drop gleam
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(dropX + 3, dropY + 4, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Eyes
    if (this.isBlinking) {
      // Blink lines
      ctx.strokeStyle = '#2b3144';
      ctx.lineWidth = 3.5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(leftEyeCenterX - 12, eyeY);
      ctx.quadraticCurveTo(leftEyeCenterX, eyeY + 5, leftEyeCenterX + 12, eyeY);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(rightEyeCenterX - 12, eyeY);
      ctx.quadraticCurveTo(rightEyeCenterX, eyeY + 5, rightEyeCenterX + 12, eyeY);
      ctx.stroke();
    } else {
      const eyeRadiusX = 14;
      const eyeRadiusY = 19;

      // Draw both eyes
      [leftEyeCenterX, rightEyeCenterX].forEach((cx) => {
        // Eye white
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(cx, eyeY, eyeRadiusX, eyeRadiusY, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#2d3748';
        ctx.lineWidth = 2.2;
        ctx.stroke();

        // Pupil tracking
        const pupilX = cx + this.currentEyeX;
        const pupilY = eyeY + this.currentEyeY;
        const pupilRadius = this.stress > 70 ? 7 : 9.5; // Shrinks in terror

        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.arc(pupilX, pupilY, pupilRadius, 0, Math.PI * 2);
        ctx.fill();

        // Cute anime pupil reflections
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(pupilX - 3, pupilY - 4, 3.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(pupilX + 3, pupilY + 3, 2, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // Mouth
    const mouthY = this.y + 18;
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#2b3144';
    ctx.fillStyle = '#ff6b8b';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (this.mouthState === 'scared') {
      // Wobbly open terrified mouth
      const mw = 14;
      const mh = 16;
      ctx.beginPath();
      ctx.ellipse(this.x, mouthY, mw, mh, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#2b3144';
      ctx.fill();
      ctx.stroke();
      // Little tooth
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.rect(this.x - 5, mouthY - mh + 2, 10, 4);
      ctx.fill();
    } else if (this.mouthState === 'nervous') {
      // Wavy squiggle mouth
      ctx.beginPath();
      ctx.moveTo(this.x - 14, mouthY);
      ctx.quadraticCurveTo(this.x - 7, mouthY - 4, this.x, mouthY);
      ctx.quadraticCurveTo(this.x + 7, mouthY + 4, this.x + 14, mouthY);
      ctx.stroke();
    } else if (this.mouthState === 'surprised') {
      // Cute round "o"
      ctx.beginPath();
      ctx.arc(this.x, mouthY, 8.5, 0, Math.PI * 2);
      ctx.fillStyle = '#2b3144';
      ctx.fill();
      ctx.stroke();
    } else {
      // Happy friendly smile
      ctx.beginPath();
      ctx.arc(this.x, mouthY - 4, 13, 0.2 * Math.PI, 0.8 * Math.PI);
      ctx.stroke();
    }

    ctx.restore();
  }
}

window.DeformableBubble = DeformableBubble;
