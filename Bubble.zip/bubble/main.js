/**
 * main.js - Application orchestration, input handling, UI bindings, and animation loop.
 */

window.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('bubbleCanvas');
  const ctx = canvas.getContext('2d');

  // UI elements
  const stressFill = document.getElementById('stressFill');
  const stressText = document.getElementById('stressText');
  const pokeCountVal = document.getElementById('pokeCountVal');
  const soundBtn = document.getElementById('soundBtn');
  const faceBtn = document.getElementById('faceBtn');
  const zenBtn = document.getElementById('zenBtn');
  const resetBtn = document.getElementById('resetBtn');
  const popModal = document.getElementById('popModal');
  const respawnBtn = document.getElementById('respawnBtn');
  const popPokesStat = document.getElementById('popPokesStat');

  // Viewport & DPI management
  let width = 0;
  let height = 0;
  let dpr = 1;

  function resizeCanvas() {
    dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;

    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    ctx.scale(dpr, dpr);

    if (bubble) {
      // Reposition inside bounds if needed
      bubble.x = Math.max(bubble.baseRadius, Math.min(width - bubble.baseRadius, bubble.x));
      bubble.y = Math.max(bubble.baseRadius, Math.min(height - bubble.baseRadius, bubble.y));
    }
  }

  // Create primary deformable bubble
  const initialRadius = Math.min(145, Math.max(95, Math.min(window.innerWidth, window.innerHeight) * 0.18));
  const bubble = new DeformableBubble(window.innerWidth / 2, window.innerHeight / 2, initialRadius);

  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  // Pointer interaction state
  const mousePos = { x: width / 2, y: height / 2 };
  let activePointerId = null;
  let pointerStartPos = { x: 0, y: 0 };
  let pointerStartTime = 0;
  let hasMovedSignificantly = false;

  function getCanvasCoords(e) {
    return {
      x: e.clientX,
      y: e.clientY
    };
  }

  // Pointer Down
  canvas.addEventListener('pointerdown', (e) => {
    // Unlock Web Audio context on first user gesture
    if (window.bubbleAudio) {
      window.bubbleAudio.resumeIfNeeded();
    }

    const pos = getCanvasCoords(e);
    mousePos.x = pos.x;
    mousePos.y = pos.y;

    // Check if user clicked on any floating mini-bubble to pop it first
    if (window.particleManager && window.particleManager.popMiniBubbleAt(pos.x, pos.y)) {
      return;
    }

    // If bubble is popped, clicking canvas can re-inflate it
    if (bubble.popped) {
      respawnBubble();
      return;
    }

    activePointerId = e.pointerId;
    canvas.setPointerCapture(e.pointerId);
    pointerStartPos = { x: pos.x, y: pos.y };
    pointerStartTime = performance.now();
    hasMovedSignificantly = false;

    // Check if pointer is on bubble
    const grabbed = bubble.startGrab(pos.x, pos.y);
    if (!grabbed) {
      // If clicked near the bubble edge, also trigger grab
      const dist = Math.hypot(pos.x - bubble.x, pos.y - bubble.y);
      if (dist < bubble.baseRadius * 1.5) {
        bubble.startGrab(pos.x, pos.y);
      }
    }
  });

  // Pointer Move
  canvas.addEventListener('pointermove', (e) => {
    const pos = getCanvasCoords(e);
    mousePos.x = pos.x;
    mousePos.y = pos.y;

    if (activePointerId === e.pointerId && !bubble.popped) {
      const distFromStart = Math.hypot(pos.x - pointerStartPos.x, pos.y - pointerStartPos.y);
      if (distFromStart > 8) {
        hasMovedSignificantly = true;
      }
      bubble.updateGrab(pos.x, pos.y);
    }
  });

  // Pointer Up
  canvas.addEventListener('pointerup', (e) => {
    if (activePointerId === e.pointerId) {
      const pos = getCanvasCoords(e);
      const elapsed = performance.now() - pointerStartTime;

      bubble.releaseGrab();

      // If it was a quick tap or hasn't moved much, treat as a poke!
      if (!hasMovedSignificantly && elapsed < 350) {
        if (bubble.containsPoint(pos.x, pos.y) || Math.hypot(pos.x - bubble.x, pos.y - bubble.y) < bubble.baseRadius * 1.3) {
          bubble.poke(pos.x, pos.y);
        }
      }

      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch (err) {}
      activePointerId = null;
    }
  });

  // Pointer Cancel
  canvas.addEventListener('pointercancel', (e) => {
    if (activePointerId === e.pointerId) {
      bubble.releaseGrab();
      activePointerId = null;
    }
  });

  // Ambient floating dust particles in background
  const ambientMotes = [];
  for (let i = 0; i < 35; i++) {
    ambientMotes.push({
      x: Math.random() * width,
      y: Math.random() * height,
      size: 1 + Math.random() * 2.5,
      speedX: (Math.random() - 0.5) * 0.4,
      speedY: -0.2 - Math.random() * 0.4,
      alpha: 0.15 + Math.random() * 0.35
    });
  }

  function updateAmbient() {
    for (const mote of ambientMotes) {
      mote.x += mote.speedX;
      mote.y += mote.speedY;
      if (mote.y < -10) {
        mote.y = height + 10;
        mote.x = Math.random() * width;
      }
      if (mote.x < -10) mote.x = width + 10;
      if (mote.x > width + 10) mote.x = -10;
    }
  }

  function drawAmbient() {
    ctx.save();
    for (const mote of ambientMotes) {
      ctx.globalAlpha = mote.alpha;
      ctx.fillStyle = '#bfe9ff';
      ctx.beginPath();
      ctx.arc(mote.x, mote.y, mote.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // Bubble pop event handler
  window.addEventListener('bubblePopped', (e) => {
    popPokesStat.textContent = e.detail.pokeCount || 0;
    popModal.classList.add('visible');
  });

  // Respawn / reset function
  function respawnBubble() {
    popModal.classList.remove('visible');
    const radius = Math.min(145, Math.max(95, Math.min(width, height) * 0.18));
    bubble.reset(width / 2, height / 2, radius);
  }

  respawnBtn.addEventListener('click', respawnBubble);
  resetBtn.addEventListener('click', respawnBubble);

  // Sound toggle button
  soundBtn.addEventListener('click', () => {
    if (window.bubbleAudio) {
      const isMuted = window.bubbleAudio.toggleMute();
      soundBtn.classList.toggle('active', !isMuted);
      soundBtn.innerHTML = isMuted
        ? '<span class="icon">🔇</span><span>Sound Off</span>'
        : '<span class="icon">🔊</span><span>Sound On</span>';
    }
  });

  // Face toggle button
  faceBtn.addEventListener('click', () => {
    bubble.showFace = !bubble.showFace;
    faceBtn.classList.toggle('active', bubble.showFace);
    faceBtn.innerHTML = bubble.showFace
      ? '<span class="icon">😊</span><span>Face On</span>'
      : '<span class="icon">⚪</span><span>Clean Bubble</span>';
  });

  // Zen Mode toggle button
  zenBtn.addEventListener('click', () => {
    bubble.invincible = !bubble.invincible;
    zenBtn.classList.toggle('active', bubble.invincible);
    zenBtn.innerHTML = bubble.invincible
      ? '<span class="icon">🛡️</span><span>Zen Mode</span>'
      : '<span class="icon">💥</span><span>Can Pop</span>';
  });

  // Keyboard shortcut: Space to re-inflate, M for mute
  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
      e.preventDefault();
      respawnBubble();
    } else if (e.key === 'm' || e.key === 'M') {
      soundBtn.click();
    }
  });

  // Update HUD text & Stress bar
  function updateHUD() {
    pokeCountVal.textContent = bubble.pokeCount;

    const stressPercent = Math.min(100, Math.max(0, Math.round(bubble.stress)));
    stressFill.style.width = `${stressPercent}%`;

    // Dynamic color & stress status
    if (bubble.invincible) {
      stressFill.style.background = 'linear-gradient(90deg, #38bdf8, #818cf8)';
      stressText.textContent = 'Zen Mode Active (Safe)';
    } else if (stressPercent < 30) {
      stressFill.style.background = 'linear-gradient(90deg, #34d399, #10b981)';
      stressText.textContent = 'Chill & Bubbly ✨';
    } else if (stressPercent < 60) {
      stressFill.style.background = 'linear-gradient(90deg, #fbbf24, #f59e0b)';
      stressText.textContent = 'A bit tickled... 💧';
    } else if (stressPercent < 85) {
      stressFill.style.background = 'linear-gradient(90deg, #f97316, #ef4444)';
      stressText.textContent = 'Getting nervous! ⚠️';
    } else {
      stressFill.style.background = 'linear-gradient(90deg, #ef4444, #dc2626)';
      stressText.textContent = 'PANIC! ABOUT TO POP! 💥';
    }
  }

  // Main animation frame loop
  function loop() {
    const bounds = { width, height };

    // Update state
    updateAmbient();
    bubble.update(bounds, mousePos);
    if (window.particleManager) {
      window.particleManager.update(bounds);
    }

    // Render frame
    ctx.clearRect(0, 0, width, height);

    drawAmbient();

    if (window.particleManager) {
      window.particleManager.draw(ctx);
    }

    bubble.draw(ctx);

    updateHUD();

    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);
});
